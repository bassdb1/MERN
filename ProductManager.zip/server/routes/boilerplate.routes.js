const BoilerPlateController = require("../controllers/boilerplate.controller");


module.exports = app =>{
    app.get("/api/products", BoilerPlateController.findAllBoilerPlates)
    app.post("/api/products/create", BoilerPlateController.createBoilerPlate)
    app.get("/api/products/:id", BoilerPlateController.findOneBoilerPlate)
    app.put("/api/products/update/:id", BoilerPlateController.updateOneBoilerPlate)
    app.delete("/api/products/delete/:id", BoilerPlateController.deleteBoilerPlate)
}
