// 'useState' is used to create some variables that can store some data.  //useEffect is used so we can modify the state variable
import React, {useState, useEffect} from 'react';
// We need to import 'axios' to reach the backend API
import axios from 'axios';
import {Link} from '@reach/router'


const AllProducts = () => {

      //state variable
      const [allproducts, setAllProducts] = useState([])
      const [deleteClicked, setdeleteClicked] = useState(false)

   //useEffect is used so that it will load the data only 'one time'

    useEffect(()=>{
        axios.get("http://localhost:8000/api/products")     // be sure to include full path, http://...
    // Successful data from the URL above goes in '.then(res) 'res = response' variable'
        .then(res =>{
            console.log("*********")
            console.log(res)
            console.log("*********")
        // I now want to set my data into my 'state variable' 'products' via the 'setProducts' setter
            setAllProducts(res.data.results)
        })
    // Error data goes in '.catch()'
        .catch(err =>{
            console.log(err)

            
        })

    }, [deleteClicked])


    // Click Handler - when the 'onclick' is clicked on below, it will run this function.  Get the delete route. Use backticks
    const deleteClickHandler =(e, quoteID )=>{
        axios.delete(`http://localhost:8000/api/products/delete/${quoteID}`)
        .then(res=>{
            console.log(res)
            setdeleteClicked(!deleteClicked)
        
        })

        .catch(err=>{
            console.log(err)
        })

    }

// Return the Form to the Screen
    return (
        <div>
            {      
                    // map through, loop. my 'allProducts state array' 'product' = each object in the array, 'i' = index number
                    allproducts.map((product,i)=>{

                        // You have to have 'return' or it will not display
                        return <div key= {i}className="card">  
                        <div className="card-body">
                          <h4 className="card-title">Title: {product.title}</h4>
                          {/* <h6 className="card-subtitle mb-2 text-muted">Quoted on this date: {joke.quotedOn}</h6> */}
                          <h4 className="card-title">Price: {product.price}</h4>
                          <h4 className="card-title">Description: {product.description}</h4>
                          <h6 className="card-subtitle mb-2 text-muted"></h6>
                          {/* <p className="card-text">
                            {joke.punchline}
                          </p> */}
                          {/* <Link to={`/jokes/${joke._id}`} className="card-link">View Details</Link>
                          <Link onClick ={(e)=>deleteClickHandler(e,joke._id)} to ="#!" className="card-link text-danger">Delete</Link> */}
                        
                        </div>
                      </div>
                    })
            }




            
            
        </div>
    );
};



export default AllProducts;