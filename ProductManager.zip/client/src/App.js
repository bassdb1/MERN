import logo from './logo.svg';
import './App.css';
import AllProducts from './components/AllProducts';
import Create from './components/Create';

function App() {
  return (
    <div className="App">
     {/* <h1>Product Manager</h1> */}
     {/* Tell it to Render All Products */}
     {/* <AllProducts></AllProducts> */}
     {/* <Link to= "/products/new">Create new joke</Link> */}
     <Create path = "/products/create"></Create>  

    </div>
  );
}

export default App;
