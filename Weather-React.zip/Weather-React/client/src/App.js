// import logo from './logo.svg';
import "./App.css";

import React, { useState } from "react";

// This is the API Key from OpenWeathermap
const api = {
  key: "9cc7895dca54f0c1016fdaec32f7059d",
  base: "https://api.openweathermap.org/data/2.5/",
  // base: "https://openweathermap.org/api"
};

///https://api.openweathermap.org/data/2.5/weather?q=greenville&units=metric&APPID=9cc7895dca54f0c1016fdaec32f7059d

function App() {
  const [query, setQuery] = useState("");
  const [weather, setWeather] = useState({});
  const [searched, setSearched] = useState(false);
  const [error, setError] = useState(false)
  const [errors, setErrors] = useState("")

  const search = (evt) => {
    // If the user presses "Enter", it will get the weather URL, and use what the user typed in for Queru, to get specific area
    if (evt.key === "Enter" && query.length > 0) {
      fetch(`${api.base}weather?q=${query}&units=imperial&APPID=${api.key}`)
        // get results from fetch
        .then((res) => res.json())
        // Take the results from JSON 'promise' format and set them with our setter 'SetWeather'
        .then((result) => {
          setWeather(result);
          // Sets our query to an empty string, so that once we have submitted our search button, it clears out the previous search
          setQuery("");
          if(result.weather){
            setSearched(true);
          }
          console.log(result);
          setErrors(result.message)
          setError(false)
          // Console.log to get our field names
          console.log(result.message);

        })
        }
    else{
      setError(true)
    }
  };

  // dateBuilder Function
  const dateBuilder = (d) => {
    let months = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ];
    let days = [
      "Sunday",
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
    ];

    let day = days[d.getDay()]; // This will get us the 'day' out of the 'days' array, gets between (1-6)
    let date = d.getDate(); // This will get between 1-31
    let month = months[d.getMonth()]; // This will look in our 'months' array and get between (0-11)
    let year = d.getFullYear(); // This will return like, 2021

    return `${day} ${month} ${date} ${year}`;
  };
  const Switch = (test) => {
    var now = new Date();
    console.log(now.toLocaleTimeString());
    var check = now.getHours();
    console.log(`check hours is ${check}`)
    if (check > 20) {
      console.log("it's night time")
      switch (test) {
        case "Clear":
          return "app clearnight";
        case "Rain":
          return "app nightrain";
        case "Clouds":
          return "app nightcloudy";
        case "Snow":
          return "app nightsnow";
        default:
          return "app nightbase";
      }
    } else {
      console.log("in the else")
      switch (test) {
        case "Clear":
          return "app sunny";
        case "Rain":
          return "app rain";
        case "Clouds":
          return "app cloudy";
        case "Snow":
          return "app snow";
        default:
          return "app base";
      }
    }
  };

  return (
    <>
      {searched ? (
        <main className={Switch(weather.weather[0].main)}>
          <div className="search-box">
            <input
              type="text"
              className="search-bar"
              placeholder="Search Location..."
              // Get the value of the input we typed in above
              onChange={(e) => setQuery(e.target.value)}
              // need to bind this 'value' to the query
              value={query}
              // Calling the 'Search Function above'
              onKeyPress={search}
              />
              {error ? <p>Needs an input</p> : ""}
              {errors ? <p>{errors}</p> : ""}
          </div>

          <div>
            <div className="location-box">
              <div className="location">
                {weather.name} {weather.sys.country},
              </div>
              <div className="date">{dateBuilder(new Date())}</div>
            </div>

            <div className="weather-box">
              <div className="temp">{Math.round(weather.main.temp)}°f</div>
              <div className="weather">{weather.weather[0].main}</div>
              {/* {Switch(weather.weather[0].main)} */}
            </div>
          </div>
        </main>
      ) : (
        <main>
          <div className="search-box">
          {error ? <p></p> : ""}
              {errors ? <p>{errors}</p> : ""}
            <input
              type="text"
              className="search-bar"
              placeholder="Search Location..."
              // Get the value of the input we typed in above
              onChange={(e) => setQuery(e.target.value)}
              // need to bind this 'value' to the query
              value={query}
              // Calling the 'Search Function above'
              onKeyPress={search}
            />
          </div>
        </main>
      )}
    </>
  );
}

export default App;
