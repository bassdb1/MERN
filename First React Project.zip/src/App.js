import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Hello Dojo!</h1>
      <h3>Things I need to do:</h3>
      <ol>
        <l1>Finish my work</l1><br></br>
        <l1>Workout</l1><br></br>
        <l1>Play with my kids</l1><br></br>
        <l1>Read, go to bed</l1><br></br>

      </ol>
    </div>
  );
}

export default App;
