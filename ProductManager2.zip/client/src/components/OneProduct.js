import React, {useState, useEffect} from 'react';
import axios from 'axios';
import { navigate, Link} from '@reach/router';

// State Variable to hold our pne joke detail
const OneProduct = (props) => {
    const [oneProduct, setoneProduct]= useState({})

// UseEffect is used to run only one time

    useEffect(()=>{
        axios.get(`http://localhost:8000/api/products/${props.id}`)  // this is used to make our backend API call
            .then(res=>{                                          // what we get back goes in the variable 'res' for response
                console.log(res)
                setoneProduct(res.data.results)                  // setting my 'State Variable' 'jokeinfo' with the response from my get command                   
            })
            .then(console.log(oneProduct))
            .catch(err=> console.log(err))
    },[])

    // Click Handler - when the 'onclick' is clicked on below, it will run this function.  Get the delete route. Use backticks
    const deleteClickHandler =()=>{
        axios.delete(`http://localhost:8000/api/products/delete/${props.id}`)
        .then(res=>{
            console.log(res)
            navigate("/")
        })

        .catch(err=>{
            console.log(err)
        })

    }

    return (
        <div>
            <h1>Details about this Product: {props.id} </h1>
            
            <h1>Title: {oneProduct.title}</h1>
            <p>Price: {oneProduct.price}</p>
            <p>Description: {oneProduct.description}</p>
            <button onClick = {deleteClickHandler} className="btn-danger">Delete</button>
            <Link to={`/products/update/${props.id}`}><button  className="btn-warning">Edit</button></Link>
         </div>
    );
};


export default OneProduct;