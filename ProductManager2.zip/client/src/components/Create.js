import { navigate } from '@reach/router';
import axios from 'axios';
import React, {useState} from 'react';

// Create a 'State Variable' to hold your Data, also have 'keys', 'from my model' to match
const Create = () => {
    const [forminfo, setforminfo] = useState({

// this needs to change per project, this is my model
        title:"",
        price:"",
        description:""


    })

// Create a state variable for errors

const [errors, setErrors] = useState({})


    // Change Handler - everything that is being typed in my form below goes through here
    const changehandler = (e)=>{
        setforminfo({
            ...forminfo,                         // this is the spread operator, it keeps the current data from being overwritten
            [e.target.name]:e.target.value
        })
    }
 
  // Submit Handler - when the form is 'submitted' I want it to run this 'Submit Handler' (e) = event
    const submitHandler = (e)=>{

        //prevent the page from refreshing
        e.preventDefault()

        // check to see if data is getting submitted
        console.log("submitted")

        // Run Axios to 'Post' the data - I got this route from Postman, then what data, our data is stored in 'forminfo'
        axios.post("http://localhost:8000/api/products/create", forminfo)
            .then(res=>{
                console.log("Response after posting the Form!")
                console.log(res)
               
                // If no errors - Validation
                if(res.data.results){
                    // Go back to home page
                navigate("/")
                }
                
                // Put errors here
                //seterrors(res.data.errors
                else {setErrors(res.data)
            }})
            .catch(err=> console.log("Errors!", err))
    }

    return (
        <div className = "container">
            <h1>Product Manager</h1>
            <form onSubmit = {submitHandler}>
                <div className="form-group">
                    <label>Title: </label>
                      {errors.title? <p className="text-danger">{errors.setup.message}</p> : ""}
                    <input onChange={changehandler} type="text" name="title" id="" className="form-control"/>
                </div>
                <div className="form-group">

                <label>Price: </label>
                {errors.price? <p className="text-danger">{errors.punchline.message}</p> : ""}
                <input onChange={changehandler} type="text" name="price" id="" className="form-control"/>
                    {/* <textarea onChange={changehandler} name="punchline" id="" cols="30" rows="10" className="form-control"></textarea> */}
                </div>
                <div className="form-group">
                    <label>Description: </label>
                    <input onChange={changehandler} type="text" name="description" id=""className="form-control"/>
                </div>
                <input type="submit" value="Create"/>
             </form>
        </div>





    );  
};


export default Create;