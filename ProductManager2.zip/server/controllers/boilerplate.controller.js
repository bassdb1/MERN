const BoilerPlate = require('../models/boilerplate.model');


module.exports.findAllBoilerPlates = (req, res)=>{
    BoilerPlate.find()
        .then(allBoilerPlates =>{
            res.json({results: allBoilerPlates})
        })
        .catch(err=>{
            res.json(err)
        })
}


module.exports.createBoilerPlate = (req, res)=>{

    console.log("REQUEST.BODY LOOKS LIKE THIS--->", req.body)
    BoilerPlate.create(req.body)
        .then(newBoilerPlate=>{
            res.json({results: newBoilerPlate})
        })
        .catch(err=>{
            console.log(err)
            res.json(err)
        })
}

module.exports.findOneBoilerPlate = (req, res)=>{
    BoilerPlate.findOne({_id: req.params.id })
        .then(oneBoilerPlate=>{
            res.json({results: oneBoilerPlate})
        })
        .catch(err=>res.json(err))
}

module.exports.updateOneBoilerPlate = (req, res)=>{
    BoilerPlate.findOneAndUpdate(
        {_id: req.params.id},
        req.body,
        { new: true, runValidators: true }
        )
        .then(updatedBoilerPlate =>{
            res.json({results: updatedBoilerPlate})
        })
        .catch(err=> res.json(err))
}


module.exports.deleteBoilerPlate = (req,res)=>{
    BoilerPlate.deleteOne({_id: req.params.id})
        .then(deletedBoilerPlate =>{
            res.json({results: deletedBoilerPlate})
        })
        .catch(err=> res.json(err))
}
