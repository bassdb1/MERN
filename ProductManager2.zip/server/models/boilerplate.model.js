const mongoose = require("mongoose")


const BoilerPlateSchema = new mongoose.Schema({
    title:{
        type: String,
        required:[true, "Title is required!"],
        minLength: [3, "Title must be at least 3 chars"],
        maxLength: [25, "Name can't be that long"]
    },

    price: {
        type: String,
        required: [true, "Price is required"]
    },

    description:{
        type: String,
        required:[true, "Description is required!"],
        minLength: [3, "Description must be at least 3 chars"],
        maxLength: [25, "Description can't be that long"]
    },


}, {timestamps:true})


const BoilerPlate = mongoose.model("BoilerPlate", BoilerPlateSchema );

module.exports = BoilerPlate;
