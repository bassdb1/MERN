  
import React from 'react';


const Home = (props) => {
    return (
        <div className= "container">
          {  
          !isNaN(props.route)?
            <h1>The number is: {props.route}</h1>:<h1 style={{color:props.text,backgroundColor:props.bg}}>The word is: {props.route}</h1>
          }
        </div>
    );
};



export default Home;