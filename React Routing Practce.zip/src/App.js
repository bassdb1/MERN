import logo from './logo.svg';
import { Link } from '@reach/router';
import './App.css';
import { Router } from '@reach/router';
import Home from './components/Home'

function App() {
  return (
    <div className="App">
        <Router>
            <Home path="/:route"></Home>
            <Home path="/:route/:text/"></Home>
            <Home path="/:route/:text/:bg"></Home>
        </Router>
     
    </div>
  );
}

export default App;
