import React, {useState} from 'react';



const Form = () => {

    //state variable to store the form information
    const [forminfo, setFormInfo] = useState({
        favColor:"",
       
    })

    //state variable to store all the SUBMITTED form information
    const [boxGenerator, setBoxGenerator] = useState([])



    //changehandler
    const changeHandler = (event)=>{
      
        setFormInfo({
            ...forminfo,
            [event.target.name]: event.target.value
        })

    }


    //submit handler
    const submitHandler = (event)=>{
        event.preventDefault()
        setBoxGenerator([...boxGenerator, forminfo])

 

         //reset the form info to be empty again after submitting form for the new entries
        setFormInfo({
             favColor:"",
              })

    }

    return (
        <div className="container">
            <div>
                <form onSubmit= {submitHandler}>
                    <div className="form-group">
                        <label htmlFor="">Color</label>
                        <input onChange = {changeHandler} type="text"  name = "favColor" className="form-control" value = {forminfo.favColor}/>
                    </div>
                    
                    <button type="submit" className="btn btn-primary">Add</button>
                </form>
                {/* <hr/><hr/> */}
                <br></br>

            </div>
            <div className ="d-flex justify-content-between">

                {
                  boxGenerator.map(box=>{
                      return <div className="card" style = {{backgroundColor: box.favColor, width :"200px",  height :"200px"}}>
                   
                      <div className="card-body">
                       
                      
                      </div>
                    </div>
                  })  
                }
            </div>
        </div>
    );
};



export default Form;