import logo from './logo.svg';
import './App.css';
import AllProducts from './components/AllProducts';
import Create from './components/Create';
import {Router} from '@reach/router';
import OneProduct from './components/OneProduct';
import Edit from './components/Edit';

function App() {
  return (
    <div className="App">
     {/* <h1>Product Manager</h1> */}
     {/* Tell it to Render All Products */}
     {/* <Link to= "/products/new">Create new joke</Link> */}
     <Router>
         {/* <Create path = "/products/create"></Create>   */}
         {/* <Create path = "/"></Create>   */}
         <AllProducts path ="/"></AllProducts>
         {/* ":id" is going into 'props' */}
         <OneProduct path ="/products/:id"></OneProduct>
         <Edit path="/products/update/:id"></Edit>
     </Router>

    </div>
  );
}

export default App;
