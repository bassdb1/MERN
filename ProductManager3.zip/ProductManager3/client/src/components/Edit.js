import React, {useEffect, useState} from 'react';  // useEffect to load the ASI page data.  useState to store data ina a state variable
import axios from 'axios';  // this lets us use API Endpoints
import {navigate} from '@reach/router';  // this allows me to go to my home page

// Props allows us to bring over properties
const Edit = (props) => {

    // We want to populate this form with what we get from the database, and store in a state variable
    const [oneProduct, setoneProduct] = useState({

    // I need to store my state variabels here - that will be modified.
    title:"",
    price:"",
    description:""
    })

    //useEffect - Loads only one time for data - if not it will load over and over
    useEffect(()=>{
       
        // Using Axios to go get the data from the website, be sure to include backticks.  'id' was defined on app.js
        axios.get(`http://localhost:8000/api/products/${props.id}`)

        // Whatever is returning from the axios call above is being stored here
            .then(res=>{
                console.log(res)
        // Populate the State Variable
            setoneProduct(res.data.results)
            })   
            .catch(err=>console.log(err))

        },[])

    // Submit Handler - needed to submit the edited form, 'e' = event
    
    const updateInfo = (e)=>{
        // prevent the default from the page 'refreshing the page' on submit
        e.preventDefault();
        // I need to use 'Axios' to 'Put' My data in the database - look at my routes from Postman.  be sure to include backticks.
        // .. With a put, what it needs updated (props.id), and what it needs updated with (oneProduct)
        axios.put(`http://localhost:8000/api/products/update/${props.id}`, oneProduct )
       
        // Whatever response we get back we can console.log it
            .then(res=>{
                console.log(res)

        // I want it to Naviagte me back to my 'home page' with the data changed - I will need to import Naviagte
            navigate("/")
            })
        // Any Errors
            .catch(err=>console.log(err))


    }

    // On Change Handler - needed to change the data.  'e' is taking information about the 'event' - update our 'State Variables'
    // ... Using 'setjokeinfo' as a setter to modify 'jokeinfo;

    const changehandler = (e)=>{
        
        setoneProduct({
            // we need to 'preserve' what is in the data now with the 'spread operator'
            ...oneProduct,

            [e.target.name]:e.target.value

        })

    }

    return (
        // copy over the form from my create.js, and place between the 'div's.  'Returns data to the Webpage'
        <div>
            <h3>Edit Product</h3>

            {/* When I submit this form, I want this to run the 'Submit Handler' 'updateInfo' */}
            <form onSubmit = {updateInfo}>
                <div className="form-group">
                    <label>Title: </label>
            {/* I also need to tell it we are using a change Handler to edit the data        */}
                    <input onChange={changehandler} type="text" name="title" id="" className="form-control" value={oneProduct.title}/>
                </div>
                <div className="form-group">

                <label>Price: </label>
             {/* I also need to tell it we are using a change Handler to edit the data        */}                
                    <textarea onChange={changehandler} name="price" id="" cols="30" rows="10" className="form-control" value={oneProduct.price}></textarea>
                </div>
                <div className="form-group">
                    <label>Description: </label>
                    <input type="text" name="description" id=""className="form-control" value ={oneProduct.description}/>
                </div>
                <input type="submit" value="Update Product"/>
             </form>
            
        </div>
    );
};



export default Edit;