import React, {useState, useEffect} from 'react';
import axios from 'axios';

// State Variable
const Pokemon = () => {

    const [allPokemon, setAllPokemon] = useState([])


    //useEffect is saying "upon loading of the page, run this code inside the use effect function one time"
    useEffect(()=>{
        
    }, [])

    // Using Fetch

    const getPokemon = (e)=>{
    //     fetch("https://pokeapi.co/api/v2/pokemon?limit=807")
    //     .then(res=> {
    //         return res.json()
    //     })
    //     .then(res => {
    //         console.log("************")
    //         console.log(res)
    //         // all results are stored in 'res'.results then stored in 'setAllPokemon' which is a setter for 'allpokemon'
    //         setAllPokemon(res.results)

    //     })
    //     .catch(err => console.log("ERRRORRRRRRRRRR", err))

    // Using Axios

        axios.get("https://pokeapi.co/api/v2/pokemon?limit=807")
        .then(res=>{
            console.log(res)
            setAllPokemon(res.data.results)
        })
        .catch(err=>{
            console.log(err)
        })

    }
    

    
    //console.log("logging responce outside of the fetch", res)
    return (
        <div>
            <button onClick={getPokemon}>Fetch Pokemon</button>
            <h1></h1>
            {
                allPokemon.map((pokemon, i) =>{
                    return <div key = {i} className="card">
                   
                        <p> {pokemon.name}</p>
                        {/* <a href={article.url} className="btn btn-primary">Go to full article</a> */}
                    </div>
                // </div>
                })
            }
            
        </div>
    );
};


export default Pokemon;