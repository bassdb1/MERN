import React, {useState} from 'react';




// State Variables
const FoodForm = props =>{

    const [firstname, setfirstname] = useState("");
    const [lastname, setlastname] = useState("");
    const [email, setEmail] = useState("");
    const [password, setpassword] = useState("");
    const [cpassword, setcpassword] = useState("");
   



    return(
        <div>
            <form>
                <div className="form-group">
                    <label htmlFor="">First Name:</label>
                    <input onChange = {e=> setfirstname(e.target.value)} type="text" name="" id="" className="form-control"/>
                    {/* Validation */}
                   <p className="text-danger">{firstname.length<2 && firstname.length>0? "First Name must be at least 2 characters":""}</p>
                </div>
                <div className="form-group">
                    <label htmlFor="">Last Name:</label>
                    <input onChange = {e=> setlastname(e.target.value)} type="text" name="" id="" className="form-control"/>
                      {/* Validation */}
                   <p className="text-danger">{lastname.length<2 && lastname.length>0? "Last Name must be at least 2 characters":""}</p>
                </div>
                <div className="form-group">
                    <label >Email address</label>
                    <input onChange = {e=> setEmail(e.target.value) } type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email"/>
                    <small id="emailHelp" className="form-text text-muted">We'll never share your email with anyone else.</small>
                         {/* Validation */}
                   <p className="text-danger">{email.length<2 && email.length>0? "Email must be at least 2 characters":""}</p>
                </div>
                <div className="form-group">
                    <label htmlFor="">Password:</label>
                    <input onChange = {e=> setpassword(e.target.value)} type="password" name="" id="" className="form-control"/>
                      {/* Validation */}
                   <p className="text-danger">{password.length<8 && password.length>0? "Password must be at least 8 characters":""}</p>
                </div>
                <div className="form-group">
                    <label htmlFor="">Confirm Password:</label>
                    <input onChange = {e=> setcpassword(e.target.value)} type="password" name="" id="" className="form-control"/>
                        {/* Validation */}
                   <p className="text-danger">{password===cpassword? "":"Passwords must match"}</p>
                </div>
                
                
                {/* <button type="submit" className="btn btn-primary">Submit</button> */}
            </form>

            <div>
                <h2>Your Form Data</h2>
                <p>First Name: {firstname}</p>
                <p>Last Name: {lastname}</p>
                <p>Email: {email}</p>
                <p>Password: {password}</p>
                <p>Confirm Password: {cpassword}</p>
            </div>
        </div>
    )
}


export default FoodForm;