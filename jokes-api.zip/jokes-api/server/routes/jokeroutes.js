// Make our routes

const JokeController = require("../controllers/jokecontroller");

// Routes
module.exports = app =>{                                           // app is a parameter
    app.get("/api/jokes", JokeController.findAllJokes)             // going to 'jokecontroller file, running the 'findAllJokes' Method
    app.post("/api/jokes/create", JokeController.createJoke)
    app.get("/api/jokes/:id", JokeController.findOneJoke)
    app.put("/api/jokes/update/:id", JokeController.updateOneJoke)
    app.delete("/api/jokes/delete/:id", JokeController.deleteJoke)

}
