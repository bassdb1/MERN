// Tell it we are going to use Mongoose
const mongoose = require("mongoose")

// Make a schema

const JokeSchema = new mongoose.Schema({


    setup:{
        type: String,
        required:[true, "Content is required!"],
        minLength: [10, "Quote content must be at least 10 chars"],
        maxLength: [100000000, "woah, we said quote, not lecture tho"]
    },
    
    punchline:{
        type: String,
        required:[true, "Content is required!"],
        minLength: [3, "Quote content must be at least 3 chars"],
        maxLength: [100000000, "woah, we said quote, not lecture tho"]
    },

   
}, {timestamps:true})

// Registed this DB as a Table here
const Joke = mongoose.model("Joke", JokeSchema );

// we need other files to ne able to talk to this file
module.exports = Joke;
