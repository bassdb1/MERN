// Import Mongoose
const mongoose = require('mongoose');
const db_name = "jokes_db"

// connect Mongoose to our DB, using 'db_name' variable, using string interpolation below, with backticks
mongoose.connect(`mongodb://localhost/${db_name}`, {   // route for DB server
    useNewUrlParser: true,
    useUnifiedTopology: true
})
    .then(() => console.log('Established a connection to the database'))
    .catch(err => console.log('Something went wrong when connecting to the database ', err));