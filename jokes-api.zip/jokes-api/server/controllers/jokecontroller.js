const Joke = require('../models/jokesmodel');


// functions for each of our CRUD commands

module.exports.findAllJokes = (req, res)=>{
    Joke.find()                                   // Talking to the DB 'Joke' using the 'method' 'find'
        .then(alljokes =>{                        // 'alljokes' is the variable that holds all it found
            res.json({results: alljokes})         //  respond in json, using variable 'alljokes'
        })
        .catch(err=>{                             // any errors
            res.json(err)
        })
}


module.exports.createJoke = (req, res)=>{

    console.log("REQUEST.BODY LOOKS LIKE THIS--->", req.body)
    Joke.create(req.body)     // 'create is a Mongoose cmd, that takes in the 'request body' of what was given in Postman 
        .then(newJoke=>{      // This is the variable that stores the joke from Postman  
            res.json({results: newJoke})
        })
        .catch(err=>{
            console.log(err)
            res.json(err)
        })
}

module.exports.findOneJoke = (req, res)=>{
    Joke.findOne({_id: req.params.id })
        .then(oneJoke=>{
            res.json({results: oneJoke})
        })
        .catch(err=>res.json(err))
}

module.exports.updateOneJoke = (req, res)=>{
    Joke.findOneAndUpdate(
        {_id: req.params.id},
        req.body,
        { new: true, runValidators: true }
        )
        .then(updatedJoke =>{
            res.json({results: updatedJoke})
        })
        .catch(err=> res.json(err))
}


module.exports.deleteJoke = (req,res)=>{
    Joke.deleteOne({_id: req.params.id})
        .then(deletedJoke =>{
            res.json({results: deletedJoke})
        })
        .catch(err=> res.json(err))
}
