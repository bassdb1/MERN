// Importing React - so we can use 'React Features'
import React, { Component } from 'react';


// so we can modify the 'state' variable
//class PersonCard extends Component {

// These class name is the same as the file name
// ... 'extends Component' means it is inhearting from the 'import React { Component } class

class PersonCard extends Component {

    constructor(props){
        super(props);
        this.state = {
            ageState: this.props.age
        }
    }
    render() {

    const addAge = ()=>{
        this.setState({ageState: this.state.ageState+=1})
}

    const {ageState} = this.state;
        // desconstruct from the 'props' object
        let {name, hair} = this.props
        return <div>
            <h1>Name: {name}</h1>
            <p>Age: {ageState}</p>
            <p>Hair: {hair}</p>
            <button onClick={addAge}>Add One Year</button>
        </div>;
    }
}
   // export to other pages 
export default PersonCard;